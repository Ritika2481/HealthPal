package com.ritika.appproject.fragment

import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room

import com.ritika.appproject.R
import com.ritika.appproject.adapter.DashboardRecyclerAdapter
import com.ritika.appproject.database.RestaurantDatabase
import com.ritika.appproject.database.RestaurantEntity
import com.ritika.appproject.model.Restaurant


class FavouritesFragment : Fragment() {

    lateinit var recyclerFavourites: RecyclerView
    lateinit var progressLayout: RelativeLayout
    lateinit var progressBarFav: ProgressBar
    lateinit var layoutManager:RecyclerView.LayoutManager
    lateinit var recyclerAdapter: DashboardRecyclerAdapter
    var dbResList = arrayListOf<Restaurant>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_favourites, container, false)


        progressLayout = view.findViewById(R.id.progressLayoutFav)
        progressBarFav = view.findViewById(R.id.ProgressBarFav)
        layoutManager = LinearLayoutManager(activity)
        progressLayout.visibility= View.VISIBLE

        setUpRecycler(view)
        return view
    }
    private fun setUpRecycler(view: View) {
        recyclerFavourites = view.findViewById(R.id.recyclerFavourites)
        val backgroundList= FavouritesAsync(activity as Context).execute().get()
        if(backgroundList.isEmpty()){
            progressLayout.visibility= View.GONE
            Toast.makeText(
                context, "No Restaurants in Favourites",
                Toast.LENGTH_SHORT
            ).show()
        }
        else{
            progressLayout.visibility= View.GONE
            for(i in backgroundList) {
                dbResList.add(
                    Restaurant(
                        i.id,
                        i.name,
                        i.costForTwo,
                        i.rating,
                        i.imageUrl

                    )
                )
            }
            recyclerAdapter= DashboardRecyclerAdapter(activity as Context,dbResList)
            layoutManager= LinearLayoutManager(activity)
            recyclerFavourites.layoutManager= layoutManager
            recyclerFavourites.itemAnimator= DefaultItemAnimator()
            recyclerFavourites.adapter= recyclerAdapter
            recyclerFavourites.setHasFixedSize(true)

        }


    }

    class FavouritesAsync(context: Context): AsyncTask<Void,Void,List<RestaurantEntity>>() {
        val db= Room.databaseBuilder(context, RestaurantDatabase::class.java,"res-db").build()
        override fun doInBackground(vararg params: Void?): List<RestaurantEntity> {
            return db.restaurantDao().getAllRes()
        }

    }
}