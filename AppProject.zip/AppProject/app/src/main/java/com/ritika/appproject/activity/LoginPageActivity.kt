package com.ritika.appproject.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.session.MediaSessionManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.foodrunner.util.SessionManager
import com.ritika.appproject.R
import com.ritika.appproject.util.ConnectionManager
import com.ritika.appproject.util.Validations
import org.json.JSONException
import org.json.JSONObject
import org.w3c.dom.Text
import java.lang.Exception
import javax.xml.validation.Validator

class LoginPageActivity : AppCompatActivity() {

    lateinit var etMobileNumber: EditText
    lateinit var etPassword: EditText
    lateinit var btnLogin: Button
    lateinit var txtForgot: TextView
    lateinit var txtRegister: TextView
    lateinit var sharedPreferences: SharedPreferences
    lateinit var sessionManager:SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)


        etMobileNumber= findViewById(R.id.etMobileNumber)
        etPassword= findViewById(R.id.etPassword)
        btnLogin= findViewById(R.id.btnLogin)
        txtForgot= findViewById(R.id.txtForgotPassword)
        txtRegister= findViewById(R.id.txtRegisterYrsf)
        sessionManager= SessionManager(this)



       sharedPreferences= this.getSharedPreferences(sessionManager.PREF_NAME, Context.MODE_PRIVATE) as SharedPreferences


        txtRegister.setOnClickListener{

            val intent= Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
        txtForgot.setOnClickListener{
            val intent= Intent(this, ForgotPasswordActivity::class.java)
            startActivity(intent)
        }

        btnLogin.setOnClickListener {
            btnLogin.visibility= View.INVISIBLE


            if(Validations.validateMobile(etMobileNumber.text.toString()) && Validations.validatePasswordLength(etPassword.text.toString())){
            if(ConnectionManager().checkConnectivity(this@LoginPageActivity))
            {

                val queue = Volley.newRequestQueue(this@LoginPageActivity)

                val jsonParams = JSONObject()
                jsonParams.put("mobile_number", etMobileNumber.text.toString())
                jsonParams.put("password", etPassword.text.toString())


                val jsonObjectRequest = object : JsonObjectRequest(Method.POST, "http://13.235.250.119/v2/login/fetch_result/", jsonParams,
                    Response.Listener {

                        try {
                            val data = it.getJSONObject("data")
                            val success = data.getBoolean("success")
                            if (success) {
                                val response = data.getJSONObject("data")
                                sharedPreferences.edit()
                                    .putString("user_id", response.getString("user_id")).apply()
                                sharedPreferences.edit()
                                    .putString("user_name", response.getString("name")).apply()
                                sharedPreferences.edit()
                                    .putString(
                                        "user_mobile_number",
                                        response.getString("mobile_number")
                                    )
                                    .apply()
                                sharedPreferences.edit()
                                    .putString("user_address", response.getString("address"))
                                    .apply()
                                sharedPreferences.edit()
                                    .putString("user_email", response.getString("email")).apply()
                                sessionManager.setLogin(true)
                                startActivity(
                                    Intent(
                                        this@LoginPageActivity,
                                        MainActivity::class.java
                                    )
                                )
                                finish()
                            } else {
                                btnLogin.visibility = View.VISIBLE
                                txtForgot.visibility = View.VISIBLE
                                btnLogin.visibility = View.VISIBLE
                                val errorMessage = data.getString("errorMessage")
                                Toast.makeText(
                                    this@LoginPageActivity,
                                    errorMessage,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } catch (e: JSONException) {
                            btnLogin.visibility = View.VISIBLE
                            txtForgot.visibility = View.VISIBLE
                            txtRegister.visibility = View.VISIBLE
                            e.printStackTrace()
                        }
                    },
                    Response.ErrorListener {
                        btnLogin.visibility = View.VISIBLE
                        txtForgot.visibility = View.VISIBLE
                        txtRegister.visibility = View.VISIBLE
                        Log.e("Error::::", "/post request fail! Error: ${it.message}")
                    }) {
                    override fun getHeaders(): MutableMap<String, String> {
                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"

                        headers["token"] = "4bcc8808439ca2"
                        return headers
                    }
                }
                queue.add(jsonObjectRequest)
            }
            else{

                btnLogin.visibility= View.VISIBLE
                Toast.makeText(this, "No Internet Connection",Toast.LENGTH_SHORT)
                    .show()
            }
        } else{
                btnLogin.visibility= View.VISIBLE
                Toast.makeText(this, "Invalid Phone or Password",Toast.LENGTH_SHORT)
                    .show()
            }
        }
        }

    }

