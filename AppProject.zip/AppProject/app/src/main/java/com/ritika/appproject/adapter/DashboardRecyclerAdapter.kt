package com.ritika.appproject.adapter

import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room

import com.ritika.appproject.R
import com.ritika.appproject.database.RestaurantDatabase
import com.ritika.appproject.database.RestaurantEntity
import com.ritika.appproject.fragment.RestaurantFragment
import com.ritika.appproject.model.Restaurant
import com.squareup.picasso.Picasso


class DashboardRecyclerAdapter(val context: Context, val itemList:ArrayList<Restaurant>):
    RecyclerView.Adapter<DashboardRecyclerAdapter.DashboardViewHolder> (){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view = LayoutInflater.from(parent.context).
            inflate(R.layout.dashboard_recycler, parent, false)

        return DashboardViewHolder(view)
    }

    override fun getItemCount(): Int {
return itemList.size
    }

    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
      val restaurant= itemList[position]
        holder.txtRestaurantName.text= restaurant.restaurantName
        holder.txtRestaurantRating.text= restaurant.restaurantRating
        holder.txtRestaurantCost.text= "Cost for one: Rs.${restaurant.restaurantCost}"
        Picasso.get().load(restaurant.restaurantImage).error(R.drawable.burger_grill).into(holder.imgRestaurantImage)

        val resEntity = RestaurantEntity(restaurant.restaurantId,
            restaurant.restaurantName,
            restaurant.restaurantRating,
                restaurant.restaurantCost,
                        restaurant.restaurantImage
        )

        val checkFav= DBAsyncTask(context, resEntity, 1).execute()
        val isFav= checkFav.get()
        if(isFav){
            holder.btnAddtoFavHeart.text = "Added to Favourites"
            val favColor= ContextCompat.getColor(context, R.color.colorFavourite)
            holder.btnAddtoFavHeart.setBackgroundColor(favColor)
        }
        else{
            holder.btnAddtoFavHeart.text = "Add to Favourites"
            val nofavColor= ContextCompat.getColor(context, R.color.colorPrimary)
            holder.btnAddtoFavHeart.setBackgroundColor(nofavColor)
        }

        holder.btnAddtoFavHeart.setOnClickListener {
            if(!DBAsyncTask(context, resEntity, 1).execute().get()){

                val async = DBAsyncTask(context, resEntity, 2).execute()
                val result= async.get()
                if(result)
                {
                    Toast.makeText(
                        context, "Restaurant Added to Favourites",
                        Toast.LENGTH_SHORT
                    ).show()

                    holder.btnAddtoFavHeart.text = "Remove from Favourites"
                    val favColor= ContextCompat.getColor(context, R.color.colorFavourite)
                    holder.btnAddtoFavHeart.setBackgroundColor(favColor)
                }
                else
                {
                    Toast.makeText(
                        context, "Error occured",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            else{

                val async = DBAsyncTask(context, resEntity, 3).execute()
                val result= async.get()
                if(result)
                {
                    Toast.makeText(
                        context, "Restaurant removed from Favourites",
                        Toast.LENGTH_SHORT
                    ).show()

                    holder.btnAddtoFavHeart.text = "Add to Favourites"
                    val nofavColor= ContextCompat.getColor(context, R.color.colorPrimary)
                    holder.btnAddtoFavHeart.setBackgroundColor(nofavColor)
                }
                else
                {
                    Toast.makeText(
                        context, "Error occured",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }


        holder.content.setOnClickListener {
            val fragment = RestaurantFragment()
            val args = Bundle()
            args.putInt("id", restaurant.restaurantId as Int)
            args.putString("name", restaurant.restaurantName)
            fragment.arguments = args
            val transaction =
                (context as FragmentActivity).supportFragmentManager.beginTransaction()
            transaction.replace(R.id.frame, fragment)
            transaction.commit()
            (context as AppCompatActivity).supportActionBar?.title = restaurant.restaurantName
        }

    }
    class DashboardViewHolder(view: View): RecyclerView.ViewHolder(view){
        val txtRestaurantName: TextView= view.findViewById(R.id.txtRestaurantName)
        val txtRestaurantCost: TextView= view.findViewById(R.id.txtRestaurantCost)
        val txtRestaurantRating: TextView= view.findViewById(R.id.txtRestaurantRating)
        val btnAddtoFavHeart: Button= view.findViewById(R.id.btnAddtoFavHeart)
        val imgRestaurantImage: ImageView = view.findViewById(R.id.imgRestaurantImage)
        val content: LinearLayout= view.findViewById(R.id.content)
    }
    class DBAsyncTask (val context: Context, val resEntity: RestaurantEntity, val mode:Int): AsyncTask<Void, Void, Boolean>()
    {

        val db= Room.databaseBuilder(context, RestaurantDatabase::class.java, "res-db").build()

        override fun doInBackground(vararg params: Void?): Boolean {
            when(mode){
                1 -> {

                    val rest: RestaurantEntity? = db.restaurantDao().getRestaurantById(resEntity.id.toString())
                    db.close()
                    return rest!=null
                }
                2 -> {
                    db.restaurantDao().insertRes(resEntity)
                    db.close()
                    return true



                }
                3 -> {
                    db.restaurantDao().deleteRes(resEntity)
                    db.close()
                    return true



                }

            }
            return false
        }
    }


}

