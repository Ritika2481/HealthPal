package com.ritika.appproject.fragment

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.provider.Settings
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.ritika.appproject.R
import com.ritika.appproject.adapter.DashboardRecyclerAdapter
import com.ritika.appproject.database.RestaurantDatabase
import com.ritika.appproject.database.RestaurantEntity
import com.ritika.appproject.model.Restaurant
import com.ritika.appproject.util.ConnectionManager
import org.json.JSONException
import java.util.*
import kotlin.Comparator
import kotlin.collections.HashMap

class DashboardFragment : Fragment() {


    lateinit var recyclerDashboard: RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager

    lateinit var recyclerAdapter: DashboardRecyclerAdapter
    val restaurantList = arrayListOf<Restaurant>()
    lateinit var progressLayout: RelativeLayout
    lateinit var progressBar: ProgressBar
    var ratingComparator= Comparator<Restaurant>{restaurant1, restaurant2 ->

        if(restaurant1.restaurantRating.compareTo(restaurant2.restaurantRating,true)==0)
        {
            restaurant1.restaurantName.compareTo(restaurant2.restaurantRating,true)
        }
        else
        {
            restaurant1.restaurantRating.compareTo(restaurant2.restaurantRating,true)
        }

    }

    var costComparator= Comparator<Restaurant>{restaurant1, restaurant2 ->

        if(restaurant1.restaurantCost.compareTo(restaurant2.restaurantCost,true)==0)
        {
            restaurant1.restaurantName.compareTo(restaurant2.restaurantCost,true)
        }
        else
        {
            restaurant1.restaurantCost.compareTo(restaurant2.restaurantCost,true)
        }

    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)
setHasOptionsMenu(true)
        recyclerDashboard = view.findViewById(R.id.recyclerDashboard)



        progressLayout = view.findViewById(R.id.progressLayout)
        progressBar = view.findViewById(R.id.ProgressBar)
        progressLayout.visibility = View.VISIBLE



        layoutManager = LinearLayoutManager(activity)


        val queue = Volley.newRequestQueue(activity as Context)
        val url = "http://13.235.250.119/v2/restaurants/fetch_result/"


        if (ConnectionManager().checkConnectivity(activity as Context)) {
            val jsonObjectRequest =
                object : JsonObjectRequest(Request.Method.GET, url, null, Response.Listener {
                    try {
                        progressLayout.visibility = View.GONE


                        val data = it.getJSONObject("data")
                        val success = data.getBoolean("success")
                        if (success) {
                            val resArray = data.getJSONArray("data")
                            for (i in 0 until resArray.length()) {
                                val resObject = resArray.getJSONObject(i)
                                val restaurant = Restaurant(
                                    resObject.getString("id").toInt(),
                                    resObject.getString("name"),
                                    resObject.getString("cost_for_one"),
                                    resObject.getString("rating"),
                                    resObject.getString("image_url")
                                )
                                restaurantList.add(restaurant)
                                recyclerAdapter =
                                    DashboardRecyclerAdapter(activity as Context, restaurantList)

                                recyclerDashboard.adapter = recyclerAdapter
                                recyclerDashboard.layoutManager = layoutManager

                            }
                        } else {
                            Toast.makeText(
                                activity as Context,
                                "some error occured",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: JSONException) {
                        Toast.makeText(
                            activity as Context, "some error occured",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                }, Response.ErrorListener {


                    Toast.makeText(
                        activity as Context, "Volley error occured",
                        Toast.LENGTH_SHORT
                    ).show()


                }) {

                    override fun getHeaders(): MutableMap<String, String> {


                        val headers = HashMap<String, String>()
                        headers["Content-type"] = "application/json"
                        headers["token"] = "4bcc8808439ca2"


                        return headers
                    }

                }
            queue.add(jsonObjectRequest)


        } else {
            val dialog = AlertDialog.Builder(activity as Context)
            dialog.setTitle("Error")
            dialog.setMessage("No Internet Connection Found")
            dialog.setPositiveButton("Open Settings") { text, listener ->
                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                activity?.finish()
            }
            dialog.setNegativeButton("Cancel") { text, listener ->

                ActivityCompat.finishAffinity(activity as Activity)
            }
            dialog.create()
            dialog.show()
        }


        return view
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater?.inflate(R.menu.menu_dashboard,menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id= item?.itemId
        if(id== R.id.action_sort) {
            Collections.sort(restaurantList, ratingComparator)

        restaurantList.reverse()
        }
        if(id== R.id.action_sortC) {
            Collections.sort(restaurantList, costComparator)

            restaurantList.reverse()
        }
        if(id== R.id.action_sortLtoH) {
            Collections.sort(restaurantList, costComparator)

        }
        recyclerAdapter.notifyDataSetChanged()
        return super.onOptionsItemSelected(item)
    }
}

