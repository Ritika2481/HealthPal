package com.ritika.appproject.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface orderDao{

    @Insert
    fun insertOrder(orderEntity: orderEntity)

    @Delete
    fun deleteOrder(orderEntity: orderEntity)

    @Query("SELECT * FROM orders")
    fun getAllOrders(): List<orderEntity>

    @Query("DELETE FROM orders WHERE resId = :resId")
    fun deleteOrders(resId: String)
}