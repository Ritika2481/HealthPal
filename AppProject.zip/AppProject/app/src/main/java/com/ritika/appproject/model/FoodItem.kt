package com.ritika.appproject.model

data class FoodItem (
    val Id: String,
    val resItemName: String,
    val resItemCost: Int

)