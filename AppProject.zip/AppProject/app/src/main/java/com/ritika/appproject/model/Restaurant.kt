package com.ritika.appproject.model

data class Restaurant (
    val restaurantId: Int,
    val restaurantName: String,
    val restaurantCost: String,
    val restaurantRating: String,
val restaurantImage: String


)