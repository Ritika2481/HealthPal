package com.ritika.appproject.fragment

import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.ritika.appproject.R

class ProfileFragment : Fragment() {
    lateinit var name : TextView
    lateinit var email : TextView
    lateinit var number : TextView
    lateinit var address : TextView


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view= inflater.inflate(R.layout.fragment_profile, container, false)

        name= view.findViewById(R.id.txtPName)
        email= view.findViewById(R.id.txtPEmail)
        number=view.findViewById(R.id.txtPMobile)
        address=view.findViewById(R.id.txtPAddress)


        return view
    }

}
